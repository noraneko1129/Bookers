class Home < ApplicationRecord
end
